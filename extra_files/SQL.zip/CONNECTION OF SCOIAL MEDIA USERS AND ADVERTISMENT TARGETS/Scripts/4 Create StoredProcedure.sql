--Filter users by country
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Madan Thapa
-- Create date: 06/01/2019
-- Description:	Filter users country
-- =============================================
CREATE PROCEDURE Users_Address 
	-- Add the parameters for the stored procedure here
	@Country VarChar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SELECT        Profile.Name, Profile.Address, Address.Country
FROM            Address INNER JOIN
                         Profile ON Address.AddressId = Profile.Address
WHERE        (Address.Country = @Country)
ORDER BY Address.Country
END
GO


-- Filter Users by the group they are in
create PROCEDURE Group_Members 
	-- Add the parameters for the stored procedure here
	@Group VarChar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
Select dbo.Profile.Name, dbo.[Group].Name AS [Group], dbo.Event.Name As Event
from	dbo.Profile Left Outer join
		dbo.Member on dbo.Profile.ProfileId = dbo.Member.ProfileId Left outer join
		dbo.[Group] on dbo.Member.GroupId = dbo.[Group].GroupId left outer join
		dbo.Event on dbo.[Group].GroupId = dbo.Event.GroupId
Where	(dbo.[Group].Name = @Group)
order by dbo.Profile.Name
END
GO

-- So Post details via post ID
Create PROCEDURE PostInformations 
	-- Add the parameters for the stored procedure here
	@ID Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SELECT        Post.PostId,[Post Reactions].[Post Content], [Post Reactions].sender, [Post Reactions].[total about of Angry], [Post Reactions].[total about of HAHA], [Post Reactions].[total about of Like], [Post Reactions].[total about of Sad], 
                         [Post Reactions].[total about of Love], [Post Reactions].[total about of WOW], [Post Reactions].[Total Reactions] 
FROM            [Post Reactions] Inner JOIN
                Post on [Post Reactions].[Post Content]=CAST(dbo.Post.Content AS VARCHAR(MAX))
Where	(Post.PostId = @ID)
order by Post.PostId
END
GO

-- Show people with certain intrest only
CREATE PROCEDURE Intrest
	-- Add the parameters for the stored procedure here
	@Activity varchar(50) ='' , @Television varchar(50) ='', @Book varchar(50)='', @Personality varchar(50)='', @Game varchar(50)='', @Movie varchar(50)='', @Wobsite varchar(50)=''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SELECT        ProfileId, Name, Activity, Television, Book, Personality, Game, Movie, Wobsite
FROM            [Peoples Intrest]
Where (Activity = @Activity) or (Television = @Television) or (Book = @Book) or (Personality =@Personality) or (Game=@Game) or (Movie =@Movie) or (Wobsite = @Wobsite)
order by ProfileId
END
GO

-- Show Advertisment Targets
CREATE PROCEDURE Advertisments_targets
	-- Add the parameters for the stored procedure here
	@AdvertismentsID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SELECT        TOP (100) PERCENT dbo.Advertisment.Advertisment, dbo.Advertisment.Name, dbo.Targets.Gender, dbo.Targets.AgeFrom, dbo.Targets.AgeTo, dbo.Targets.Locations, dbo.Targets.TimeZone, dbo.Activity.Name AS Activity, 
                         dbo.Website.Name AS Website, dbo.Books.Name AS Books, dbo.Television.Name AS Television, dbo.Movie.Name AS Movie, dbo.Games.Name AS Games, dbo.Personality.Name AS Personality, dbo.[Group].Name AS GroupName, 
                         dbo.Profile.Name AS Person, dbo.Event.Name AS EventName
FROM          dbo.Activity Full outer Join 
						 dbo.Targets ON dbo.Activity.ActivityId = dbo.Targets.TargetActivity Full outer JOIN
                         dbo.Advertisment ON dbo.Targets.Advertisment = dbo.Advertisment.Advertisment Full outer JOIN
                         dbo.Books ON dbo.Targets.TargetBooks = dbo.Books.BookId Full outer JOIN
                         dbo.Movie ON dbo.Targets.TargetMovie = dbo.Movie.MovieId Full outer JOIN
                         dbo.Personality ON dbo.Targets.TargetPersonality = dbo.Personality.PersonalityId Full outer JOIN
                         dbo.Television ON dbo.Targets.TargetTelevision = dbo.Television.TelevisionId Full outer JOIN
                         dbo.Website ON dbo.Targets.TargetWebsite = dbo.Website.SiteId Full outer JOIN
                         dbo.Games ON dbo.Targets.TargetGames = dbo.Games.GameId left outer JOIN
						 dbo.[Group] ON dbo.Targets.ConnectionsGroup = dbo.[Group].GroupId left outer JOIN
						 dbo.Event ON dbo.Targets.ConnectionsEvent = dbo.Event.EventId left outer JOIN
						 dbo.Profile ON dbo.Targets.ConnectionsPeople = dbo.Profile.ProfileId
Where dbo.Advertisment.Advertisment = @AdvertismentsID
ORDER BY dbo.Advertisment.Name;
END
GO

-- ADVERTISEMENT AND USER CONNECTIONS (Profile)
CREATE PROCEDURE ADandUser
	-- Add the parameters for the stored procedure here
	@Gender Varchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
SELECT        [Advertisments targets].Name, Profile.Name AS Expr1, Profile.Gender
FROM            [Advertisments targets] INNER JOIN
                         Profile ON [Advertisments targets].Gender = Profile.Gender
Where Profile.Gender = @Gender
END
GO