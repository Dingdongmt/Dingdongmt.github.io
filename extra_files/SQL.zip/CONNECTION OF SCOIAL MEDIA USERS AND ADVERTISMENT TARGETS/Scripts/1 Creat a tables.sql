/*creating tables*/
/*user*/
Create table "User" (
	UserId int not null identity (1,1) primary key,
	UserName varchar(25) NOT NULL,
	"Password" varchar(25) Not Null,
)

Create table "Address" (
	AddressId int not null identity (1,1) primary key,
	AddressLine1 varchar(100),
	AddressLine2 varchar(100),
	Town varchar(100),
	County varchar(100) Not Null,
	Country varchar(100) Not Null,
	PostCode varchar(10) Not Null,
)

Create table "Profile" (
	ProfileId int not null identity (1,1) primary key,
	UserId int not null foreign key REFERENCES "User"(UserId),
	"Address" int foreign key REFERENCES "Address"(AddressId),
	"Name" varchar(80) NOT NULL,
	Email varchar(100) Not Null,
	Gender varchar(10)
	Check([Gender] in ('Male','Female')),
	DateOfBirth date Not null,
	Phone varchar(25),
)

Create table Friend (
	FriendshipId int not null identity (1,1) primary key,
	ProfileId int not null foreign key REFERENCES "Profile"(ProfileId),
	UserId int not null foreign key REFERENCES "User"(UserId),
	FriendName varchar(80),
	AccpetedDate date not null,
	Sender varchar(80),
 )

/*groups*/
Create table "Group"(
	GroupId int not null identity (1,1) primary key,
	"Name" varchar(50) not null,
	"Description" varchar(250), 
)

Create table "Event"(
	EventId int not null identity (1,1) primary key,
	GroupId int not null foreign key REFERENCES "Group"(GroupId),
	"Name" varchar(50) not null,
	Organizer varchar(50),
	"Description" varchar(250),
	Venu int foreign key REFERENCES "Address"(AddressId),
	"From" datetime,
	"To" datetime,
)

Create table Member (
	MemberId int not null identity (1,1) primary key,
	ProfileId int not null foreign key REFERENCES "Profile"(ProfileId),
	GroupId int not null foreign key REFERENCES "Group"(GroupId),
	JoinedDate date not null,
	MemberName varchar(80),
	"Role" varchar(25) not null
	Check([Role] in ('Member','Admin','Editor','Moderator','Owner')),
 )

 /*interest*/
 Create table Interest(
	InterestId int not null identity (1,1) primary key,
	UserId int not null foreign key REFERENCES "User"(UserId),
)

Create table Games(
	GameId int not null identity (1,1) primary key,
	InterestId int not null foreign key REFERENCES Interest(InterestId),
	"Name" varchar(50) not null,
	Genre varchar(50) not null,
	"Description" varchar(250), 
)
Create table Personality(
	PersonalityId int not null identity (1,1) primary key,
	InterestId int not null foreign key REFERENCES Interest(InterestId),
	"Name" varchar(80) not null,
	Genre varchar(50) not null,
	"Description" varchar(250), 
)
Create table Website(
	SiteId int not null identity (1,1) primary key,
	InterestId int not null foreign key REFERENCES Interest(InterestId),
	"Name" varchar(50) not null,
	Genre varchar(50) not null,
	"Description" varchar(250), 
)
Create table Movie(
	MovieId int not null identity (1,1) primary key,
	InterestId int not null foreign key REFERENCES Interest(InterestId),
	"Name" varchar(50) not null,
	Genre varchar(50) not null,
	"Description" varchar(250), 
)
Create table Books(
	BookId int not null identity (1,1) primary key,
	InterestId int not null foreign key REFERENCES Interest(InterestId),
	"Name" varchar(50) not null,
	Genre varchar(50) not null,
	"Description" varchar(250), 
)
Create table Television(
	TelevisionId int not null identity (1,1) primary key,
	InterestId int not null foreign key REFERENCES Interest(InterestId),
	"Name" varchar(50) not null,
	Genre varchar(50) not null,
	"Description" varchar(250), 
)
Create table Activity(
	ActivityId int not null identity (1,1) primary key,
	InterestId int not null foreign key REFERENCES Interest(InterestId),
	"Name" varchar(50) not null,
	Genre varchar(50) not null,
	"Description" varchar(250), 
)

/*posts and Comments*/
 Create table "Post"(
	PostId int not null identity (1,1) primary key,
	ProfileId int not null foreign key REFERENCES "Profile"(ProfileId),
	Content Text not null,
	sender varchar(80),
 )

  Create table Comments(
	CommentId int not null identity (1,1) primary key,
	ProfileId int not null foreign key REFERENCES "Profile"(ProfileId),
	PostId int not null foreign key REFERENCES "Post"(PostId),
	Content Text not null,
	Sender varchar(80),
 )
 
 /*Reaction Tables*/
Create table Loves(
	ReactionType int not null primary key,
	ProfileId int foreign key REFERENCES "Profile"(ProfileId),
	"Name" varchar(80),
)
Create table Likes(
	ReactionType int not null primary key,
	ProfileId int foreign key REFERENCES "Profile"(ProfileId),
	"Name" varchar(80),
)
Create table HAHA(
	ReactionType int not null primary key,
	ProfileId int foreign key REFERENCES "Profile"(ProfileId),
	"Name" varchar(80),
)
Create table WOW(
	ReactionType int not null primary key,
	ProfileId int foreign key REFERENCES "Profile"(ProfileId),
	"Name" varchar(80),
)
Create table Sad(
	ReactionType int not null primary key,
	ProfileId int foreign key REFERENCES "Profile"(ProfileId),
	"Name" varchar(80),
)
Create table Anger(
	ReactionType int not null primary key,
	ProfileId int foreign key REFERENCES "Profile"(ProfileId),
	"Name" varchar(80),
)

/* this was created to make it easier for the relationship/code betweeen reactions and post/comments */
Create table Love_Comment (
	Love int foreign key REFERENCES Loves(ReactionType),
	CommentId int foreign key REFERENCES Comments(CommentID),
)
Create table Likes_Comment (
	"Like" int foreign key REFERENCES Likes(ReactionType),
	CommentId int foreign key REFERENCES Comments(CommentID),
)
Create table HAHA_Comment (
	Haha int foreign key REFERENCES HAHA(ReactionType),
	CommentId int foreign key REFERENCES Comments(CommentID),
)
Create table WOW_Comment (
	Wow int foreign key REFERENCES WOW(ReactionType),
	CommentId int foreign key REFERENCES Comments(CommentID),
)
Create table Sad_Comment (
	Sad int foreign key REFERENCES Sad(ReactionType),
	CommentId int foreign key REFERENCES Comments(CommentID),
)
Create table Anger_Comment (
	Anger int foreign key REFERENCES Anger(ReactionType),
	CommentId int foreign key REFERENCES Comments(CommentID),
)

Create table Love_Post (
	Love int foreign key REFERENCES Loves(ReactionType),
	PostId int foreign key REFERENCES Post(PostId),
)
Create table Likes_Post (
	"Like" int foreign key REFERENCES Likes(ReactionType),
	PostId int foreign key REFERENCES Post(PostId),
)
Create table HAHA_Post (
	Haha int foreign key REFERENCES HAHA(ReactionType),
	PostId int foreign key REFERENCES Post(PostId),
)
Create table WOW_Post (
	Wow int foreign key REFERENCES WOW(ReactionType),
	PostId int foreign key REFERENCES Post(PostId),
)
Create table Sad_Post (
	Sad int foreign key REFERENCES Sad(ReactionType),
	PostId int foreign key REFERENCES Post(PostId),
)
Create table Anger_Post (
	Anger int foreign key REFERENCES Anger(ReactionType),
	PostId int foreign key REFERENCES Post(PostId),
)

 /*private details*/
  Create table "Log"(
	LogId int not null identity (1,1) primary key,
	UserId int not null foreign key REFERENCES "User"(UserId),
 )

 Create table Searched_History(
	SearchedId int not null identity (1,1) primary key,
	LogId int not null foreign key REFERENCES "Log"(LogId),
	"Search" varchar(100) not null,
	"Time" datetime not null
 )

 Create table "LoginAndLogout"(
	LoginAndLogout int not null identity (1,1) primary key,
	LogId int not null foreign key REFERENCES "Log"(LogId),
	"login" bit not null,
	"Time" datetime not null,
	IPAddress varchar(50),
	"Site" varchar(2083),
	DeviceName varchar(80),
	DeviceType varchar(50),
	"Address" int foreign key REFERENCES "Address"(AddressId),
	Cookie varchar(50)
 )

  Create table Status_changes(
	StatusId int not null identity (1,1) primary key,
	LogId int not null foreign key REFERENCES "Log"(LogId),
	StatusType bit not null,
	Calls bit not null,
	PostTabs bit not null,
 )

 /*Advertisment*/
 Create table Advertisment(
	Advertisment int not null identity (1,1) primary key,
	"Name" varchar(80) not null,
	"Address" int foreign key REFERENCES "Address"(AddressId),
	"Number" varchar(50),
)
Create table Targets(
	TargetId int not null identity (1,1) primary key,
	Advertisment int foreign key REFERENCES Advertisment(Advertisment),
	Locations varchar(100),
	TimeZone varchar(100),
	ConnectionsPeople varchar(100),
	ConnectionsGroup varchar(100),
	ConnectionsEvent varchar(100),
	AgeFrom int,
	AgeTo int,
	Gender varchar(50) Check([Gender] in ('Male','female')),
	TargetGames int foreign key REFERENCES Games(GameId),
	TargetPersonality int foreign key REFERENCES Personality(PersonalityId),
	TargetWebsite int foreign key REFERENCES Website(SiteId),
	TargetMovie int foreign key REFERENCES Movie(MovieId),
	TargetBooks int foreign key REFERENCES Books(BookId),
	TargetTelevision int foreign key REFERENCES Television(TelevisionId),
	TargetActivity int foreign key REFERENCES Activity(ActivityId),
)
