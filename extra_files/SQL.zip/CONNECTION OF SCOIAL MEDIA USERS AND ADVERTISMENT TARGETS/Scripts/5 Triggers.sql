-- Creation of the feedback table
Create table TriggerFeedback (
	ID int not null identity (1,1) primary key,
	"feedback Message" varchar(max)
)

-- Creation of the INSERT trigger
Go
Create Trigger Added_User
on "User"
for insert
as
begin
	declare @Id int
	Select @Id = UserId from inserted

	insert into TriggerFeedback
	values ('New user with ID ='+ CAST(@Id as varchar(10))+' is added at '+cast(GETDATE() as nchar(100))
)
End

-- Creation of the DELETE trigger
Go
Create Trigger Deleted_User
on "User"
for DELETE
as
begin
	declare @Id int
	Select @Id = UserId from deleted

	insert into TriggerFeedback
	values ('User with ID ='+ CAST(@Id as varchar(10))+' was Deleted at '+cast(GETDATE() as nchar(100))
)
End

-- creation of the DLL Trigger on Create_table, Alter_table, Drop_table
create Trigger DDLTrigger
On database
For Create_table, Alter_table, Drop_table
As
begin
	insert into TriggerFeedback
	Values ('You have just made changed to the datebase at '+ cast(GETDATE() as nchar(100)))
End

-- creation of the roleback DLL Trigger on Create_table, Alter_table, Drop_table
Create Trigger DDLTrigger_Denied
On database
For Create_table, Alter_table, Drop_table
As
begin
	Rollback
	insert into TriggerFeedback
	Values ('You have NOT made changed to the datebase at '+ cast(GETDATE() as nchar(100)))
End

--Disabaling the roleback DLL Trigger
DISABLE trigger DDLTrigger_Denied