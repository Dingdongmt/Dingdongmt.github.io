/*advertisment and its targets*/
Create view [Advertisments targets] As
SELECT        TOP (100) PERCENT dbo.Advertisment.Advertisment, dbo.Advertisment.Name, dbo.Targets.Gender, dbo.Targets.AgeFrom, dbo.Targets.AgeTo, dbo.Targets.Locations, dbo.Targets.TimeZone, dbo.Activity.Name AS Activity, 
                         dbo.Website.Name AS Website, dbo.Books.Name AS Books, dbo.Television.Name AS Television, dbo.Movie.Name AS Movie, dbo.Games.Name AS Games, dbo.Personality.Name AS Personality, dbo.[Group].Name AS GroupName, 
                         dbo.Profile.Name AS Person, dbo.Event.Name AS EventName
FROM          dbo.Activity Full outer Join 
						 dbo.Targets ON dbo.Activity.ActivityId = dbo.Targets.TargetActivity Full outer JOIN
                         dbo.Advertisment ON dbo.Targets.Advertisment = dbo.Advertisment.Advertisment Full outer JOIN
                         dbo.Books ON dbo.Targets.TargetBooks = dbo.Books.BookId Full outer JOIN
                         dbo.Movie ON dbo.Targets.TargetMovie = dbo.Movie.MovieId Full outer JOIN
                         dbo.Personality ON dbo.Targets.TargetPersonality = dbo.Personality.PersonalityId Full outer JOIN
                         dbo.Television ON dbo.Targets.TargetTelevision = dbo.Television.TelevisionId Full outer JOIN
                         dbo.Website ON dbo.Targets.TargetWebsite = dbo.Website.SiteId Full outer JOIN
                         dbo.Games ON dbo.Targets.TargetGames = dbo.Games.GameId left outer JOIN
						 dbo.[Group] ON dbo.Targets.ConnectionsGroup = dbo.[Group].GroupId left outer JOIN
						 dbo.Event ON dbo.Targets.ConnectionsEvent = dbo.Event.EventId left outer JOIN
						 dbo.Profile ON dbo.Targets.ConnectionsPeople = dbo.Profile.ProfileId 
ORDER BY dbo.Advertisment.Name;

/*love post*/
GO
Create view [Post Love] As
Select CAST(dbo.Post.Content AS VARCHAR(MAX)) as Content, count(dbo.Love_Post.PostId) as "total about of Love"
from  dbo.Love_Post,dbo.Post
Where dbo.Post.PostId = dbo.Love_Post.PostId
group by CAST(dbo.Post.Content AS VARCHAR(MAX));

/* Like on post */
GO
Create view [Post like] as
Select CAST(dbo.Post.Content AS VARCHAR(MAX)) as Content, count(dbo.Likes_Post.PostId) as "total about of Like"
from  dbo.Likes_Post,dbo.Post
Where dbo.Post.PostId = dbo.Likes_Post.PostId
group by CAST(dbo.Post.Content AS VARCHAR(MAX));

/* HAHA on post */
GO
Create view [Post HAHA] as
Select CAST(dbo.Post.Content AS VARCHAR(MAX)) as Content, count(dbo.HAHA_Post.PostId) as "total about of HAHA"
from  dbo.HAHA_Post,dbo.Post
Where dbo.Post.PostId = dbo.HAHA_Post.PostId
group by CAST(dbo.Post.Content AS VARCHAR(MAX));

/* WOW on post */
GO
Create view [Post WOW] as
Select CAST(dbo.Post.Content AS VARCHAR(MAX)) as Content, count(dbo.WOW_Post.PostId) as "total about of WOW"
from  dbo.WOW_Post,dbo.Post
Where dbo.Post.PostId = dbo.WOW_Post.PostId
group by CAST(dbo.Post.Content AS VARCHAR(MAX));

/* SAD on post */
GO
Create view [Post Sad] as
Select CAST(dbo.Post.Content AS VARCHAR(MAX)) as Content, count(dbo.Sad_Post.PostId) as "total about of Sad"
from  dbo.Sad_Post,dbo.Post
Where dbo.Post.PostId = dbo.Sad_Post.PostId
group by CAST(dbo.Post.Content AS VARCHAR(MAX));

/* anger on post */
GO
Create view [Post Angry] as
Select CAST(dbo.Post.Content AS VARCHAR(MAX)) as Content, count(dbo.Anger_Post.PostId) as "total about of Angry"
from  dbo.Anger_Post,dbo.Post
Where dbo.Post.PostId = dbo.Anger_Post.PostId
group by CAST(dbo.Post.Content AS VARCHAR(MAX));

/* post reaction */
GO
Create view [Post Reactions] as
SELECT        CAST(dbo.Post.Content AS VARCHAR(MAX)) as "Post Content", dbo.Post.sender, dbo.[Post Angry].[total about of Angry], dbo.[Post HAHA].[total about of HAHA], dbo.[Post like].[total about of Like], dbo.[Post Love].[total about of Love], dbo.[Post Sad].[total about of Sad], 
                         dbo.[Post WOW].[total about of WOW], (ISNULL(dbo.[Post Angry].[total about of Angry],0) + ISNULL(dbo.[Post HAHA].[total about of HAHA],0) + ISNULL(dbo.[Post like].[total about of Like],0) + ISNULL(dbo.[Post Love].[total about of Love],0) + ISNULL(dbo.[Post Sad].[total about of Sad],0) + ISNULL(dbo.[Post WOW].[total about of WOW],0)) as "Total Reactions"
FROM            dbo.[Post Angry] Right JOIN
                         dbo.Post ON dbo.[Post Angry].[Content] = CAST(dbo.Post.Content AS VARCHAR(MAX)) left JOIN
                         dbo.[Post HAHA] ON CAST(dbo.Post.Content AS VARCHAR(MAX)) = dbo.[Post HAHA].[Content] left JOIN
                         dbo.[Post like] ON CAST(dbo.Post.Content AS VARCHAR(MAX)) = dbo.[Post like].[Content] left JOIN
                         dbo.[Post Love] ON CAST(dbo.Post.Content AS VARCHAR(MAX)) = dbo.[Post Love].[Content] left JOIN
                         dbo.[Post Sad] ON CAST(dbo.Post.Content AS VARCHAR(MAX)) = dbo.[Post Sad].[Content] left JOIN
                         dbo.[Post WOW] ON CAST(dbo.Post.Content AS VARCHAR(MAX)) = dbo.[Post WOW].[Content]

/* Peoples Intrest */
GO
create view [Peoples Intrest] as
SELECT        dbo.Profile.ProfileId, dbo.Profile.Name, dbo.Activity.Name AS Activity, dbo.Television.Name AS Television, dbo.Books.Name AS Book, dbo.Personality.Name AS Personality, dbo.Games.Name AS Game, 
                         dbo.Website.Name AS Wobsite, dbo.Movie.Name AS Movie
FROM            dbo.Profile LEFT OUTER JOIN
                         dbo.Interest ON dbo.Profile.UserId = dbo.Interest.UserId LEFT OUTER JOIN
                         dbo.Activity ON dbo.Interest.InterestId = dbo.Activity.InterestId LEFT OUTER JOIN
                         dbo.Books ON dbo.Interest.InterestId = dbo.Books.InterestId LEFT OUTER JOIN
                         dbo.Games ON dbo.Interest.InterestId = dbo.Games.InterestId LEFT OUTER JOIN
                         dbo.Movie ON dbo.Interest.InterestId = dbo.Movie.InterestId LEFT OUTER JOIN
                         dbo.Personality ON dbo.Interest.InterestId = dbo.Personality.InterestId LEFT OUTER JOIN
                         dbo.Television ON dbo.Interest.InterestId = dbo.Television.InterestId LEFT OUTER JOIN
                         dbo.Website ON dbo.Interest.InterestId = dbo.Website.InterestId

/* user private details */
GO						 
create view [User Private/Security Details] as
SELECT        dbo.[User].UserName, dbo.Searched_History.Search, dbo.Searched_History.Time, dbo.Status_changes.StatusType, dbo.Status_changes.PostTabs, dbo.Status_changes.Calls, dbo.LoginAndLogout.login, 
                         dbo.LoginAndLogout.Time AS [Login Time], dbo.LoginAndLogout.IPAddress, dbo.LoginAndLogout.Site, dbo.LoginAndLogout.DeviceName, dbo.LoginAndLogout.DeviceType, dbo.LoginAndLogout.Address, 
                         dbo.LoginAndLogout.Cookie
FROM            dbo.[User] INNER JOIN
                         dbo.[Log] ON dbo.[User].UserId = dbo.[Log].UserId INNER JOIN
                         dbo.Searched_History ON dbo.[Log].LogId = dbo.Searched_History.LogId INNER JOIN
                         dbo.Status_changes ON dbo.[Log].LogId = dbo.Status_changes.LogId INNER JOIN
                         dbo.LoginAndLogout ON dbo.[Log].LogId = dbo.LoginAndLogout.LogId
WHERE        (dbo.[User].UserName = 'venenatis')

/* user connections via groups*/
GO						 
create view [User Group] as
Select TOP(100)PERCENT dbo.Profile.Name, dbo.[Group].Name AS [Group], dbo.Event.Name As Event
from dbo.Profile Left Outer join
dbo.Member on dbo.Profile.ProfileId = dbo.Member.ProfileId Left outer join
dbo.[Group] on dbo.Member.GroupId = dbo.[Group].GroupId left outer join
dbo.Event on dbo.[Group].GroupId = dbo.Event.GroupId
Where (dbo.profile.name = 'Cameron Ingram')
order by dbo.Profile.Name
/* user connections via Friends*/
GO						 
create view [User Friends] as
Select TOP(100)PERCENT dbo.Profile.Name, dbo.Friend.Sender, dbo.Friend.AccpetedDate, dbo.Friend.ProfileId as profileId
From dbo.Profile Full outer join
dbo.Friend on dbo.Profile.ProfileId = dbo.Friend.ProfileId
where (dbo.Profile.Name = 'Dieter Yates')

/*ADVERTISEMENT AND USER CONNECTIONS*/
GO						 
create view [ADVERTISEMENT AND USER CONNECTIONS ] as
SELECT        dbo.[Advertisments targets].Name AS Advertisment, dbo.[Peoples Intrest].Name AS Target
FROM            dbo.[Advertisments targets] FULL OUTER JOIN
                         dbo.[Peoples Intrest] ON dbo.[Advertisments targets].Activity = dbo.[Peoples Intrest].Activity OR dbo.[Advertisments targets].Television = dbo.[Peoples Intrest].Television OR 
                         dbo.[Advertisments targets].Books = dbo.[Peoples Intrest].Book OR dbo.[Advertisments targets].Personality = dbo.[Peoples Intrest].Personality OR dbo.[Advertisments targets].Games = dbo.[Peoples Intrest].Game OR 
                         dbo.[Advertisments targets].Website = dbo.[Peoples Intrest].Wobsite OR dbo.[Advertisments targets].Movie = dbo.[Peoples Intrest].Movie